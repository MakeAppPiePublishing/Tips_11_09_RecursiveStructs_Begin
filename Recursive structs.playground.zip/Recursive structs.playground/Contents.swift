// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 09
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn the secret to building recursive structs, the model pattern for using the outline view in SwiftUI. 
//  For more code, go to http://bit.ly/AppPieGithub

import SwiftUI
